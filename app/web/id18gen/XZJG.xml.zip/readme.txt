
【文件说明】
中国各省市县与18位身份证号的前6位对应关系。

【更新日期】
2021.10.15

【如何找到这个文件】
1.首先来到
http://www.nciic.com.cn
（会跳转到 http://www.nciic.com.cn/framework/gongzuo/index.jsp ）

2.注意到这个 iframe
http://www.nciic.com.cn/jsp/searchtab2.html

3.在源代码中 第285行
function load_array(){
  var xmlDoc = checkXMLDocObj("XZJG.xml");
得知，此页面会加载同目录的 XZJG.xml 文件，JS 本地判断用户输入。
