#encoding='utf-8'
import pandas as pd

def main():
    '''把数据从TXT转储为csv
    '''

    print('begin transform into csv ...')

    # 导入 
    # 没有列名        header=None
    # 设定第 0 列为ID  index_col=0
    # 删除多余的第六列 全为空
    # 重命名列名
    df = pd.read_table('info_3.txt',sep='\t',encoding='utf-8',header=None,index_col=0,)
    df = df.drop(6,axis=1)
    df = df.rename(columns=lambda x: ['ID','name','sex','sexDouble','location','introduction'][x] )
    # print(df)

    df.to_csv('info_3.csv',encoding='utf-8')

    print('DONE !')

if __name__ == "__main__":
    main()