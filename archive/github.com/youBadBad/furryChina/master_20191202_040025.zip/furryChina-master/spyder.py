#encoding='utf-8'

import requests
from bs4 import BeautifulSoup
import csv 
import random
import time
import os


def urlGenerator():
# example is    https://www.furrychina.com/user/wiserxin
# the range is  1-5650
    MAX_RANGE = 5650
    for i in range(1,MAX_RANGE+1):
    # for i in range(5354,5358):
        yield r'https://www.furrychina.com/user/{}'.format(i)

def getInfo(url):
    # get the information from url 
    # and pri  analysis , get  what we need
    urlId = url.split('/')[-1]
    req = requests.get(url=url,)
    divName =   ['userpanel_displayname',   #昵称
                 'userpanel_location',      #位置
                 'userpanel_personalintro', #个人简介  
                ]
    iName =     ['fa fa-mars',              #性别
                 'fa fa-mars-double',       #取向
                 
                ]



    bf = BeautifulSoup(req.text,"lxml")
    # print(bf.find_all('div',class_ =divName))
    name,location,intro   = bf.find_all('div',class_ =divName)
    
    def clearSpace(x):
        x = x.replace('\t','')
        x = x.replace('\n','')
        x = x.replace('\r','')
        return x
    
    name = clearSpace(name.text)[1:-1]
    location = clearSpace(location.text)
    intro = clearSpace(intro.text)



    try:
        bf = BeautifulSoup( str(bf.find_all('div',class_='userpanel_gendor_block')[0]) , "lxml" )
        sex , sexDouble       = bf.find_all('i')
        sex = sex.get('title')
        sexDouble = sexDouble.get('title')
    except :
        sex , sexDouble = ['未填写','未填写']
    

    return [urlId,name,sex,sexDouble,location,intro]
    # print(req.text)

def main():
    urls = urlGenerator()
    headers = ['urlId','name','sex','sexDouble','location','intro']
    allInfo = []
    
    pwd = os.path.dirname( os.path.abspath(__file__) )    
    f = open(os.path.join(pwd,'info.txt'),'w',encoding='utf-8',)

    # 把得到的信息存储到文本中
    # 其中出现exception的 在出错位置 填入 ID 以区分
    # 不公开的页面则仅填入ID，其余项皆为 空格

    for url in urls:
        # print(getInfo(url))
        try:
            allInfo.append(getInfo(url))
            for i in allInfo[-1]:
                print(i, end = '\t',file=f,flush=False)
            print('done' , url)
        except Exception as e:
            urlId = url.split('/')[-1]
            print(urlId, end = '\t',file=f,flush=False)
            print('fake' , url)
            print(e)
            input('键入回车以继续...')
            pass
            # print([urlId,'不公开个人主页'])
        finally:
            print('',flush=False,file=f)
            time.sleep(random.random()/5.0)
    f.close()

    # with open('info.csv','w')as f:
    #     f_csv = csv.writer(f)
    #     f_csv.writerow(headers)
    #     f_csv.writerows(allInfo)

if __name__ == "__main__":
    main()
    