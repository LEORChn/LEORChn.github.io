运行方式： python GUI.py

时间顺序：

spyder.py               初步爬取数据 ，存储于 info_1.txt 认为 不公开的、出现异常的 为Fake数据

checkFake.py            提取Fake数据的ID

analysisException.py    分析出现异常的原因 , 解决并重新爬取，存储于info_2.txt

combine.py              把 info_1 中的 异常 Fake 替换为 info_2 中的True Info

updateNewMate.py        更新信息 自动爬取直至末位用户

transformIntoCsv.py     使用info_3.txt生成csv表格

fetchFurryInfo.py       检索

GUI.py                  图形界面
