#encoding='utf-8'

import tkinter as tk
import fetchFurryInfo


def main():
    inf = fetchFurryInfo.main()
    root=tk.Tk()
    root.title('="w"=')
    root.geometry('1200x310')



    e=tk.Entry(root,font=("黑体", 20, "bold"))
    s1 = tk.Scrollbar(root)
    # HORIZONTAL 设置水平方向的滚动条，默认是竖直
    s2 = tk.Scrollbar(root, orient = tk.HORIZONTAL)
    t=tk.Text(root,height=10,font=("黑体", 14, "bold"),
              yscrollcommand = s1.set, 
              xscrollcommand = s2.set,
              wrap = 'none',    # wrap 设置不自动换行
              undo=False,       # 不存储每次的更改信息，减少内存占用，该选项为TRUE则 在TEXT 内的操作可撤销
              )


    e.pack()#side = tk.TOP
    s1.pack(side = tk.RIGHT, fill = tk.Y)
    s2.pack(side = tk.BOTTOM, fill = tk.X)
    t.pack(expand = tk.YES, fill = tk.BOTH,  side = tk.BOTTOM)

    s1.config(command = t.yview)
    s2.config(command = t.xview)
    
    t.insert('end',inf.getInfo2Str(e.get()))
    t.config(state=tk.DISABLED)  # 变为不可编辑模式

    
    eGetBuffer = '' #buffer ， 记录上一次的输入，若entry内文字未改变，则不检索信息
    def enterAChar(event):
        nonlocal eGetBuffer # nonlocal: 在局部寻找外层函数中离他最近的那个变量   #global: 在局部访问全局中的内容
        temp = e.get()
        if eGetBuffer == temp:
            # print('temp:[{}]\tbuf:[{}]'.format(temp,eGetBuffer))
            pass
        else:        
            print('[{}]'.format(temp))
            t.config(state=tk.NORMAL)  # 取消不可编辑
            t.delete(1.0,tk.END)
            t.insert('end', inf.getInfo2Str(temp) )
            t.config(state=tk.DISABLED)  # 变为不可编辑模式
        eGetBuffer = temp


    e.bind("<KeyRelease>", enterAChar)

    root.mainloop()





if __name__ == "__main__":
    main()

