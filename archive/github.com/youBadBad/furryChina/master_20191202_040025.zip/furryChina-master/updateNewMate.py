#encoding='utf-8'
from functools import reduce
import requests
from bs4 import BeautifulSoup
import csv 
import random
import time
import os
from combine import fun

def makeUrlByID(ID:int):
    return r'https://www.furrychina.com/user/{}'.format(ID)

def urlGenerator(beginNum:int):
# example is    https://www.furrychina.com/user/wiserxin
    while True:
        yield makeUrlByID(beginNum)
        beginNum += 1


def getInfo(url):
    # get the information from url 
    # and pri  analysis , get  what we need
    urlId = url.split('/')[-1]
    req = requests.get(url=url,)
    divName =   ['userpanel_displayname',   #昵称
                 'userpanel_location',      #位置
                 'userpanel_personalintro', #个人简介  
                ]
    iName =     ['fa fa-mars',              #性别
                 'fa fa-mars-double',       #取向
                 
                ]


    bf = BeautifulSoup(req.text,"lxml")
    # print(bf.find_all('div',class_ =divName))
    
    # 获取divName中的信息，并鉴定是否到达末位用户
    try:
        # 正常读取
        name,location,intro   = bf.find_all('div',class_ =divName)
    except Exception as e:
        # 出现异常
        temp = bf.find_all('div',class_ ='errorContent')[0]
        if ('主页地址错误或账号状态异常，看看其他人的主页吧~' in str(temp)):
            # 到达末位
            raise EOFError
        else:
            # 其它异常
            raise e

    
    def clearSpace(x):
        x = x.replace('\t','')
        x = x.replace('\n','')
        x = x.replace('\r','')
        return x
    
    name = clearSpace(name.text)[1:-1]
    location = clearSpace(location.text)
    intro = clearSpace(intro.text)



    try:
        bf = BeautifulSoup( str(bf.find_all('div',class_='userpanel_gendor_block')[0]) , "lxml" )
        sex , sexDouble       = bf.find_all('i')
        sex = sex.get('title')
        sexDouble = sexDouble.get('title')
    except :
        sex , sexDouble = ['未填写','未填写']
    

    return [urlId,name,sex,sexDouble,location,intro]
    # print(req.text)

def updateOneMateByID(ID:int):
    url = makeUrlByID(ID)
    s = ''
    try:
        s = reduce( lambda x,y: "{}\t{}".format(x,y) , getInfo(url))
        s += '\t\n'
    except EOFError:
        s = ''
        print('查无此人')
    except Exception as e:
        s = ''
        print('该用户未公开信息')
        print(e)
    
    if s=='':
        pass
    else: # 写入更改
        pwd = os.path.dirname( os.path.abspath(__file__) )    
        temp = None
        with open(os.path.join(pwd,'info_3.txt'),'r',encoding='utf-8',) as f:
            temp = f.readlines()
        if temp:
            with open(os.path.join(pwd,'info_3.txt'),'w',encoding='utf-8',) as f:
                temp[ID-1] = s
                f.writelines(temp)
        print("update user:{} done!\tinfo is:\n{}".format(ID,s))
        

def main():
    pwd = os.path.dirname( os.path.abspath(__file__) )    
    f = open(os.path.join(pwd,'info_3.txt'),'r+',encoding='utf-8',)

    beginNum = 0
    for line in f:
        beginNum , _ = fun(line)
    print("now final one's ID is",beginNum)
    print('ready ? \t GO !')
    # input('ready ? ')


    urls = urlGenerator(int(beginNum)+1)
    headers = ['urlId','name','sex','sexDouble','location','intro']
    allInfo = []

    # 把得到的信息存储到文本中
    # 其中出现exception的 在出错位置 填入 ID 以区分
    # 不公开的页面则仅填入ID，其余项皆为 空格
    newMateCount = -1   #计数，增加了几个新兽友
    for url in urls:
        # print(getInfo(url))
        try:
            allInfo.append(getInfo(url))
            for i in allInfo[-1]:
                print(i, end = '\t',file=f,flush=False)
            print('',flush=False,file=f)
            
            print('done' , url)

        except EOFError as e:
            # 是已经没有用户了
            print('finish fetching info !')
            break
        except Exception as e:
            # 普通的异常
            # print([urlId,'不公开个人主页'])
            urlId = url.split('/')[-1]
            print(urlId, end = '\t',file=f,flush=False)
            print('',flush=False,file=f)

            print('fake {}\n' 
                  '{}'  
                  ''.format(url,e))
            input('键入回车以继续...')
        finally:
            time.sleep(random.random()/5.0)
            newMateCount+=1
    
    f.close()
    print("{}! {} new furry friends have grown!"
          "".format(
                ['Oops','Congratulations',][newMateCount>0] , 
                newMateCount
                )
         )


if __name__ == "__main__":
    main()
    updateOneMateByID(5089)
