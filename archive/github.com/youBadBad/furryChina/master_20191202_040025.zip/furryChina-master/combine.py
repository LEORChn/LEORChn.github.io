#encoding='utf-8'

def fun(x):
    ID = x.split('\t')[0]
    return ID,x

if __name__ == "__main__":
    with open('info_1.txt','r') as old, open('info_2.txt','r',encoding='utf-8') as new, open('info_3.txt','w',encoding='utf-8') as res:
        
        resData = ''
        newID , newData = fun(new.readline())
        
        for oldLine in old:
            oldID, oldData = fun(oldLine)
            if newID == oldID:
                resData = newData
                try:
                    newID , newData = fun(new.readline())
                except Exception as e:
                    print(e)
                    pass
            else:
                resData = oldData
            res.write(resData)
                        

