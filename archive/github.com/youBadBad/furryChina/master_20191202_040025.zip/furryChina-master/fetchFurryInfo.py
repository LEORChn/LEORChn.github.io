#encoding='utf-8'
# 使用 Data 为 info_3.txt

import pandas as pd
import numpy as np

import transformIntoCsv
import updateNewMate

# -*- coding: utf-8 -*-

def my_align(_string, _length, _type='L'):
    """
    中英文混合字符串对齐函数
    my_align(_string, _length[, _type]) -> str

    :param _string:[str]需要对齐的字符串
    :param _length:[int]对齐长度
    :param _type:[str]对齐方式（'L'：默认，左对齐；'R'：右对齐；'C'或其他：居中对齐）
    :return:[str]输出_string的对齐结果

    理论上讲应该是正确的，研究了下应该是中英文混排的时候，实际中文字宽不等于2倍英文字宽造成的，包括用全角空格和半角空格补充字符串混排也是对不齐的。
    于是我就去找了个中英文混合等宽字体，微软雅黑与Consolas的混合：YaHei Consolas Hybrid，改上去。
    顺便说一句，还有个【更纱黑体（Sarasa Gothic）】也不错，但英文太窄了看不习惯，想要的可以去GitHub找到。
    
    from https://www.jianshu.com/p/74500b7dc278 on 2019-11-30/09:39
    """
    _str_len = len(_string)  # 原始字符串长度（汉字算1个长度）
    for _char in _string:  # 判断字符串内汉字的数量，有一个汉字增加一个长度
        if u'\u4e00' <= _char <= u'\u9fa5':  # 判断一个字是否为汉字（这句网上也有说是“ <= u'\u9ffff' ”的）
            _str_len += 1
    _space = _length-_str_len  # 计算需要填充的空格数
    if _type == 'L':  # 根据对齐方式分配空格
        _left = 0
        _right = _space
    elif _type == 'R':
        _left = _space
        _right = 0
    else:
        _left = _space//2
        _right = _space-_left
    return ' '*_left + _string + ' '*_right


class FurryData :
    def __init__(self):
        # 可以写成单例模式
        self.data = pd.read_csv('info_3.csv').rename(index=str, columns={"0": "ID"})
        # 把 NA 未填写 [未填写地点] [用户还未设置个人签名。] 换成 空
        self.data = self.data.fillna(value='--')
        for i in ['未填写', '[未填写地点]','[未填写地点] ', '[用户还未设置个人签名。]']:
            self.data.replace(i, '--', inplace=True)


    def update(self ):
        updateNewMate.main()
        transformIntoCsv.main()
        self.__init__()

    def upgrade(self, parameter_list):
        pass

    def search(self, keyWord:str):
        keyWordLocation = 0
        columnNames = list(self.data)
        for columnName in columnNames[1:]:
            temp = self.data[columnName]
            keyWordLocation = ( temp.str.contains(keyWord, case=False) == True
                                if type(keyWordLocation) is int 
                                else (keyWordLocation | (temp.str.contains(keyWord, case=False) == True) )
                              )
        # print(keyWordLocation)
        return self.data[keyWordLocation]

    def getByID(self, ID:int):
        return self.data.iloc[ID-1,:]

    def df2list(self, df):
        # df is pandas.dataframe || pandas.series
        return np.array(df).tolist()

    def getInfo(self, keyWord):
        # return  [ [column Names] , [search result a] , ... , [search result n] ]
        r = [list(self.data)]
        # 尝试按ID搜索
        try:
            temp = self.getByID(int(keyWord))
            r.append(self.df2list(temp))
        except Exception as e:
            pass
        
        # 按文本搜索
        r.extend(self.df2list(self.search(keyWord)))
        
        return r

    def info2Str_simple(self, info:list): 
        # 将一条记录转换成字符串
        r = ''
        for i in info:
            r += str(i).ljust(14)
            r += '\t'
        r += '\n'
        return r
    
    def info2Str(self, info:list): 

        # 将一条记录转换成字符串
        length = [6,14,8,14,16,20]
        r = ''
        for i in range(0,len(length)):
            r += ' '+my_align( str(info[i]), length[i] )
        r += '\n'
        return r

    

    def getInfo2Str(self,keyWord):
        r = ''
        for i in self.getInfo(keyWord):
            r += self.info2Str(i)
        return r

        
def main():
    info = FurryData()
    info.update()
    return info



if __name__ == "__main__":
    info = main()
    # print(info.search('akako'))
    # print(type(info.search('赤琥')))
    # print(type(info.getByID(1)))

    for i in info.getInfo('akak'):
        print(info.info2Str(i),end='')
