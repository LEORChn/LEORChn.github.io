#encoding='utf-8'

from checkFake import expID

from spyder import getInfo

def urlGenerator():
# example is    https://www.furrychina.com/user/wiserxin
    for i in expID:
        yield r'https://www.furrychina.com/user/{}'.format(i)


def expInfoGenerator(show=False):
    urls = urlGenerator()
    for url in urls:
        if(show):
            print('get',url)
        yield getInfo(url)


if __name__ == "__main__":
    expInfo = expInfoGenerator(True)
    # 在打开文件时，指定编码为 utf-8 就不会出问题了 o(╥﹏╥)o
    with open('info.txt','w', encoding='utf-8') as f:
        for i in expInfo:
            # print(i)
            f.write( '{}\t{}\t{}\t{}\t{}\t{}\t\n'.format(i[0],i[1],i[2],i[3],i[4],i[5]) )
            # input('continue ...')